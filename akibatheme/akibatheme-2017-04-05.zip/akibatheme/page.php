<?php get_header(); ?>

			<div id="content">
			<div id="inner-content" class="wrap cf">
				<div class="m-all t-all d-all cf">
					<header class="article-header">

									

								</header> <?php // end article header ?>
					
				</div>
			</div>
			
			<div class="standard-header">
					<div id="inner-content" class="wrap wrap-small cf">
						<div class="m-all t-all d-all cf">
						<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
						</div>
					</div>
				</div>
				
				
				<div id="inner-content" class="wrap wrap-small cf">

						<main id="main" class="m-all t-all d-all standard-body cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									
								</header> <?php // end article header ?>

								<section class="entry-content cf" itemprop="articleBody">
									<?php
										the_content();

									
										wp_link_pages( array(
											'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
											'after'       => '</div>',
											'link_before' => '<span>',
											'link_after'  => '</span>',
										) );
									?>
								</section> <?php // end article section ?>

								

							</article>

							<?php endwhile; ?>
								
							<?php else : ?>

								<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'No Articles Yet', 'bonestheme' ); ?></h1>
									</header>
									<footer class="article-footer">
											<p>Can't find what you're looking for? Try looking again, or go back to our <a href="<?php echo get_home_url(); ?>">Home Page</a>.</p>
									</footer>
								</article>
								
								<?php endif; ?>

						</main>


				</div>

			</div>

<?php get_footer(); ?>

