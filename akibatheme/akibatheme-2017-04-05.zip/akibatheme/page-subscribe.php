<?php
/*
 Template Name: Subscribe
*/
?>

<?php get_header(); ?>


<?php
	
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
	$form = get_post_meta($post->ID, 'wpcf-subscribe-form', true);
	?>
			<div id="content">
				 <?php
				                if(has_post_thumbnail()) { ?>
				               <section class="subscribe-wall" style="background-image: url('<?php echo $featuredImage; ?>');">
				
				            <?php } else { ?>
				             
				             	<section class="subscribe-wall">

				            <?php } ?>
				            
				            <div class="subscribe-overlay">
				   
				
					<div id="inner-content" class="wrap wrap-small cf">
						
						
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">
										<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
								</header> <?php // end article header ?>

								<section class="entry-content cf" itemprop="articleBody">
									<?php
										the_content(); ?>
								</section> <?php // end article section ?>


								

							</article>

							<?php endwhile; endif; ?>

						</main>
						
					</div>
					 </div>
				</section>
				
				<section class="subscribe-form" id="subscribe">
				<div id="inner-content" class="wrap wrap-tiny cf">

							<?php echo apply_filters('the_content',$form); ?>


				</div>
				
				</section>

			</div>

<?php get_footer('dark'); ?>
