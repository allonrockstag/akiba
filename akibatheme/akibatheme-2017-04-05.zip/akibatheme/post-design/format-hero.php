
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article" itemscope itemprop="blogPost" itemtype="http://schema.org/BlogPosting">
	              
	            <div class="m-all t-all d-all cf">
		            	<div class="post-header post-header-hero">
                <header class="article-header entry-header">
					
					<p class="byline entry-meta vcard">
						 <?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
											
											

                  </p>
                  
                  
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  
                  <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>

                  <hr>
                  
		         <span class="author">	
				<?php $author = get_the_author(); ?>
				<p>By 
				<?php if($author == 'admin'){ ?>
					Akiba Press
				<?php } else { ?>
					<?php echo $author; ?>	
				<?php } ?>
				
				<time class="update entry-time" datetime="<?php get_the_time('Y-m-d')?>" itemprop="datePublished"><?php the_time('F j, Y'); ?></time>
				</p>
				</span>
				
				<span class="share-this">	
				
				<ul class="post-share-tablet">
					<h4>Share</h4>
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
				</span>
				

                </header> <?php // end article header ?>
                
					</div> <!-- END POST HEADER -->
	            </div>
	           
	           
	            <div class="m-all t-all d-all cf">
	          
	          <!-- <section class="adspace-banner"> 
		          <span></span>
	           </section>
	           
	           -->
	            </div>
	           <section class="wrap-post-article">
		           
			  	<div class="m-all t-all d-1of7 cf share-bar"> <!-- POST SHARE BAR -->
			  		
				  	<ul class="post-share" id="postsharehero">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
				  	<span class="spacer">&nbsp;</span>
			  	</div>
				<div class="m-all t-all d-6of7 last-col cf"> <!-- POST ARTICLE -->
					
				
				
				
				<div class="post-article post-article-hero">
					
                <section class="entry-content cf" itemprop="articleBody">
	          
	               
                  <?php
                    // the content (pretty self explanatory huh)
                    the_content();

                    /*
                     * Link Pages is used in case you have posts that are set to break into
                     * multiple pages. You can remove this if you don't plan on doing that.
                     *
                     * Also, breaking content up into multiple pages is a horrible experience,
                     * so don't do it. While there are SOME edge cases where this is useful, it's
                     * mostly used for people to get more ad views. It's up to you but if you want
                     * to do it, you're wrong and I hate you. (Ok, I still love you but just not as much)
                     *
                     * http://gizmodo.com/5841121/google-wants-to-help-you-avoid-stupid-annoying-multiple-page-articles
                     *
                    */
                    wp_link_pages( array(
                      'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
                      'after'       => '</div>',
                      'link_before' => '<span>',
                      'link_after'  => '</span>',
                    ) );
                  ?>
                </section> <?php // end article section ?>

                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
                  <section class="ac-container">
	                  <?php $countfaq = 1; ?>
	                  <div class="ac-container-box">
								<input id="ac-<?php echo $countfaq ?>" name="accordion-<?php echo $countfaq ?>" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>">
								 <span class="comment-icon"><i class="fa fa-comment" aria-hidden="true"></i></span><?php comments_number( __( '<span>No</span> Comments', 'bonestheme' ), __( '<span>One</span> Comment', 'bonestheme' ), __( '<span>%</span> Comments', 'bonestheme' ) );?>
								</label>
								<article class="ac-small">
									<?php comments_template(); ?>
								</article>
						</div>


	                 
	                  	
                  	</section>

                </footer> <?php // end article footer ?>

               
                
                
				</div>
                 
                 
                 
                 </div>
                 
	           </section> <!--end wrap-post-article -->
                 


              </article> <?php // end article ?>
              
              
			
			 
			 
		 	