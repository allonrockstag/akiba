<?php
/*
 Template Name: Videos
*/
?>

<?php get_header(); ?>

<?php // Calling Youtube Data API.
$subscribers = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=UCK2AySrPmblKipyNY1V2iiQ&key=AIzaSyDVMBpcQn9ZMhrCRvqt3ZHdCLHx3CZnjvA');
// Decoding json response
$response = json_decode($subscribers, true );
// echoing subscribers count.
 $api_response_decoded = intval($response['items'][0]['statistics']['subscriberCount']);
 
 ?>
 
 

			<div id="content"> 
				
				<section class="section-videos transition-height">
					<div class="videos-content transition-height">
						<div id="inner-content" class="wrap wrap-full cf transition-height">
							
							<div class="page-header-videos">
								<div class="m-all t-all d-all cf transition-height">
								<h1><span>Videos</span></h1>
								
								
								
								<div class="tabs tabs-style-iconbox">
										
										<div class="content-wrap">
											
											
											<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 5, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
									$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
									$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
									$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
								<section id="section-iconbox-<?php echo $countpost;?>">
												
												
												
												
												<div class="tab-video-area">
												<?php if($vidtype == '1' && !empty($vidyoutube)){ ?>
												<?php $embed_code = wp_oembed_get($vidyoutube); ?>
												
												<?php echo $embed_code; ?>
															
												<?php } ?>
												
												<?php if($vidtype == '2' && !empty($vidvimeo)){ ?>
												<?php $embed_code = wp_oembed_get($vidvimeo); ?>
												
												<?php echo $embed_code; ?>
															
												<?php }?>
												
												</div>
												<div class="tab-video-text">
													
												<h2><?php the_title(); ?></h2>
												<p><?php the_excerpt(); ?></p>
												<p class="byline entry-meta">
													<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
												</p>
												</div>
											</section>
									  
						 	
						 	
									  
									  <?php
									  
									endforeach; 
									wp_reset_postdata();
									?>

								 

										</div><!-- /content -->
									
										<nav class="tab-nav">
										<ul>
											
											
								
								
											<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 4, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
									$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
									$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
									$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
									  
											<li id="pause-button-<?php echo $countpost;?>" class="tab-not-current"><a href="#section-iconbox-<?php echo $countpost;?>" class="icon icon-home"><span>
												<h3><?php the_title(); ?></h3>
												<p><?php the_excerpt(); ?></p>
												<p class="byline entry-meta vcard">
										        	<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>

												</p>
												</span>
												
							<?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videotabimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videotabimage"></div>

				            <?php } ?>
				            
				            </a></li>
										
												
 
									  <?php
									  
									endforeach; 
									wp_reset_postdata();
									?>
									
										</ul>
									</nav>
									
								</div><!-- /tabs -->
							
							</div>
							</div>
						</div> <!-- end inner-content -->
						
						
						
						

					</div> <!-- end videos-content -->
				</section>
				
				
				<section class="videos-content">
					<div id="inner-content" class="wrap wrap-full cf">
						<div class="m-all t-all d-all cf video-area-footer">
							<div class="videos-more">
								<h2 class="category-title">Explore Videos</h2>
							</div>
							<div class="youtube-btn">
								<a href="https://www.youtube.com/channel/UCK2AySrPmblKipyNY1V2iiQ"><span>
								<p>Akiba Press Youtube Channel</p>
								<address><?php echo $api_response_decoded; ?> Subscribers</address>
								</span></a>
							</div>
						</div>
						</div>
						
				<div id="inner-content" class="wrap wrap-full cf">
				

				
						<div class="m-all t-1of3 d-2of7 cf video-list-side">
						<?php get_sidebar('videos'); ?>
						</div>
				
				
						<main id="main" class="m-all t-2of3 d-5of7 cf last-col" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
					<ul class="video-list">	
						
					
					<?php
				    $loop = new WP_Query( array( 'post_type' => 'video', 'posts_per_page' => 3, 'paged' => $paged ) );
				    if ( $loop->have_posts() ) :
				        while ( $loop->have_posts() ) : $loop->the_post();
				        $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
				            
				            
				            <li class="list-item">
					            <a id="list-item-image" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
					            <?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videoimage" style="background-image: url('<?php echo $featuredImage; ?>');"><span>Video</span></div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videoimage"><span>Video</span></div>

				            <?php } ?>
				            </a>
				            
					            <a id="list-item-text" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span>
												<h3><?php the_title(); ?></h3>
												<p class="byline entry-meta vcard">
										        	<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>

												</p>
												</span></a>
												
							
				            
				            </li>
				        <?php endwhile; ?>
				        
				           <?php bones_page_navi(); ?>
				       
				  <?php  endif;
				    wp_reset_postdata();
				?>
				
					</ul>
					
					
					
						</main>

						<div class="m-all t-all d-all cf">
							<div class="youtube-btn youtube-btn-mobile">
							<a href="https://www.youtube.com/channel/UCK2AySrPmblKipyNY1V2iiQ"><span>
							<p>Akiba Press Youtube Channel</p>
							<address>55 Subscribers</address>
							</span></a>
							</div>
							</div>
						</div>
				
				
				
							
							
				</section><!-- end video-content -->

			</div>

<?php get_footer(); ?>
