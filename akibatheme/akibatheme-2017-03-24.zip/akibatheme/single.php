<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
	?>

							
	<?php if($design == '2'){ ?>
			<?php get_header('dark'); ?>
			<div id="content" class="nopadding">	
				
				<?php if(has_post_thumbnail()) { ?>
	         <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
	                   
			<section class="post-hero" style="background-image:	 url('<?php echo $featuredImage; ?>')"> </section>			
	            <?php } else { ?>
	             
	            <?php } ?>
	            
	             			
	<?php } else { ?>
			<?php get_header(); ?>					
			<div id="content">
	<?php } ?>
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

			
				<?php if($design == '2'){ ?>
						
				<?php } else { ?>
						<?php echo wp_get_attachment_image( $post->ID , array('700', '600'), "", array( "class" => "img-responsive" ) );  ?>

	                <?php if(has_post_thumbnail()) { ?>
	                <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
				                   <img class="article-feature-img-mobile" src="<?php echo $featuredImage; ?>" alt="">
											
				            <?php } else { ?>
				             
				            <?php } ?>						
				<?php } ?>
				
				
				<?php if($design == '2'){ ?>
							<div id="inner-content" class="wrap wrap-post cf">					
				<?php } else { ?>
							<div id="inner-content" class="wrap wrap-2 cf">					
				<?php } ?>
				
				

					<main id="main" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">


						<?php if (have_posts()) : while (have_posts()) : the_post();
							$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
							 ?>
						
						
							<?php if($design == '2'){ ?>
								<?php get_template_part( 'post-design/format-hero', get_post_format() ); ?>
							<?php } else { ?>
								<?php
								/*
								 * Ah, post formats. Nature's greatest mystery (aside from the sloth).
								 *
								 * So this function will bring in the needed template file depending on what the post
								 * format is. The different post formats are located in the post-formats folder.
								 *
								 *
								 * REMEMBER TO ALWAYS HAVE A DEFAULT ONE NAMED "format.php" FOR POSTS THAT AREN'T
								 * A SPECIFIC POST FORMAT.
								 *
								 * If you want to remove post formats, just delete the post-formats folder and
								 * replace the function below with the contents of the "format.php" file.
								*/
								get_template_part( 'post-formats/format', get_post_format() );
							?>
							
							
							<?php } ?>
							
							
							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
									<h4>Share</h4>
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
							</div>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'Oops, Post Not Found!', 'bonestheme' ); ?></h1>
									</header>
									<section class="entry-content">
										<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'bonestheme' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'This is the error message in the single.php template.', 'bonestheme' ); ?></p>
									</footer>
							</article>

						<?php endif; ?>

						
						
				
						
					</main>
					
					
					
				</div> <!-- end inner-content -->
				
				
				<section class="article-morearticles">
					<div class="wrap cf">
						<div class="m-all t-2of3 d-5of7 cf">
								sadas
						</div>
						<div class="m-all t-1of3 d-2of7 cf last-col">
							<?php get_sidebar(); ?>
						</div>
					</div>
				</section>

			</div> <!-- end #content -->

<?php get_footer(); ?>


