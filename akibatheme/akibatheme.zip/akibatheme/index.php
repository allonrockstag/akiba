<?php get_header(); ?>

			<div id="content">
				
				<div id="inner-content" class="wrap cf">
				
				<section class="page-header">
					<div class="page-header-title">
					<h1>News</h1>
					</div>
					
					<div class="page-header-side">
							
					<select>
					  <option value="volvo">Volvo</option>
					  <option value="saab">Saab</option>
					  <option value="mercedes">Mercedes</option>
					  <option value="audi">Audi</option>
					</select>
					</div>
				</section>
				
				<section class="article-hero">
					
					
					<ul class="block-hero m-all t-all d-all cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 1, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
									  
									  <?php if($countpost == 1) { ?>
										  <div class="block-hero-table">
										  <li class="block-hero-1">
									  <?php } else { ?>
										  <li>
									  <?php } ?> 
									  
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									<p class="byline entry-meta vcard">
                                     <span><?php the_time('F j, Y'); ?></span>
									</p>
									<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
							</article>
							
							
							<?php if($countpost == 1) { ?>
										  
										  </li>
										  </div>
									  <?php } else { ?>
										  </li>
									  <?php } ?> 
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
									
									<div class="block-hero-table-2">
									
									<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 3, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 1 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
									  
										  <li class="block-hero-2">
									  
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									<p class="byline entry-meta vcard">
                                     <span><?php the_time('F j, Y'); ?></span>
									</p>
									<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
							</article>
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
									
									</div>
									
								</ul>	
								
								
				</section>				
						



						<main id="main" class="m-all t-2of3 d-4of7 cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
																
							
							
							<ul class="block-list">
								
								
								<h2 class="category-title">More News</h2>
								
								<?php  $countpost = 0; ?>
							
							<?php if (have_posts()) : while (have_posts()) : the_post();
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							    $post_type = get_post_type_object( get_post_type($post) );
							    $shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
							     $countpost++;
					     ?>
						 	
						 	
						 	<?php if($countpost > 4){ ?> 
						 	<li>
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									<p class="byline entry-meta vcard">
                                     <span><?php the_time('F j, Y'); ?></span>
									</p>
									<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
							</article>
							
							</li>

						 	
						 	
						 	<?php } ?>
						 	
						 	
						 	
						 	
							<?php endwhile; ?>
							
							</ul>

									<?php bones_page_navi(); ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
											<header class="article-header">
												<h1><?php _e( 'Oops, Post Not Found!', 'bonestheme' ); ?></h1>
										</header>
											<section class="entry-content">
												<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'bonestheme' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( 'This is the error message in the index.php template.', 'bonestheme' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>


						</main>


						
					<div class="m-all t-1of3 d-3of7 cf">
					<?php get_sidebar('news'); ?>
				</div>

				</div>
				
				
				
						
						

			</div>


<?php get_footer(); ?>
