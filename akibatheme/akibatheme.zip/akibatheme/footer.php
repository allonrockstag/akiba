			<footer class="footer" id="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">

				<div id="inner-footer" class="wrap cf">
					
					
					<div class="m-1of2 t-1of4 d-1of7">
						
						<h4>Sections</h4>
						<nav role="navigation">
						<?php wp_nav_menu(array(
    					'menu' => __( 'Footer Links', 'bonestheme' ),   // nav name
    					'menu_class' => 'footer-nav cf',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
						</nav>
					
					</div>
					<div class="m-1of2 t-1of4 d-1of7 cf">
						<h4>Reviews</h4>
						<nav role="navigation">
						<?php wp_nav_menu(array(  
    					'menu' => __( 'Footer Links', 'bonestheme' ),  
    					'menu_class' => 'footer-nav cf',       
    					'depth' => 0
						)); ?>
						</nav>
						</div>

						<div class="m-1of2 t-1of4 d-1of7 cf">
							<h4>News</h4>
						<nav role="navigation">
						<?php wp_nav_menu(array( 
    					'menu' => __( 'Footer Links', 'bonestheme' ),  
    					'menu_class' => 'footer-nav cf',       
    					'depth' => 0
						)); ?>
						</nav>
						</div>


					
					<div class="m-all t-all d-all cf">
					<p class="source-org copyright">&copy; <?php echo date('Y'); ?> Akiba Press. All Rights Reserved.</p>
					</div>

				</div>

			</footer>

		</div>

		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>
		
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/jquery-2.1.1.js"></script>
		<?php include('jscript-main.php');?>


	</body>

</html> <!-- end of site. what a ride! -->
