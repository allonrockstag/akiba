<div class="sb-search-background"></div>

<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">


	<input class="sb-search-input" placeholder="Search for a supplier.." type="text" value="" name="s" id="s">
	<input class="sb-search-submit" type="submit" value="">
	<input type="hidden" name="post_type" value="supplier" />
	<span class="sb-icon-search"></span>

	
</form>


