<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap cf errorpage">

					<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

						<article id="post-not-found" class="hentry cf">

							<header class="article-header">

								<h1><?php _e( 'No Content Found', 'bonestheme' ); ?></h1>

							</header>

							<section class="entry-content">

								<p>Can't find what you're looking for? Try looking again, or go back to our <a href="<?php echo get_home_url(); ?>">Home Page</a>.</p>

							</section>

							

							<footer class="article-footer">

									<section class="search">
 
									<p><?php get_search_form(); ?></p>

							</section>

							</footer>
							
							
							

						</article>

					</main>

				</div>

			</div>

<?php get_footer(); ?>
