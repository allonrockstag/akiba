<?php if (have_posts()) : while (have_posts()) : the_post();
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
	$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
	$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
	$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
	$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
	$post_type_name = get_post_type( $post->ID );
	$post_type = get_post_type_object( get_post_type($post) );
	$embed_code = wp_oembed_get($vidyoutube);
	$embed_code2 = wp_oembed_get($vidvimeo);
	$embed_code3 = wp_oembed_get($vidfb);
	?>
	
			<?php get_header('dark'); ?>
			<div id="content" class="nopadding">
				
				<?php if(has_post_thumbnail()) { ?>
	         <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
	                   
			<section class="post-hero post-hero-video" style="background-image:	 url('<?php echo $featuredImage; ?>')">
				<div class="post-hero-video-overlay">
				</div>
						
	            <?php } else { ?>
	              <section class="post-hero post-hero-video">
	            <?php } ?>
				
				<div id="inner-content" class="wrap wrap-videopost cf">	
					
					
				<div class="m-all t-all d-1of8 cf share-bar share-bar-video">
				  	<ul class="post-share post-share-video">
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
				  	<span class="spacer">&nbsp;</span>
			  	</div>
			  	
			  	<div class="m-all t-all d-7of8 cf post-article-normal">
				  		<div class="m-all t-all d-3of4 cf">	
							<div class="post-video-area">
								<?php if($vidtype == '1' && !empty($vidyoutube)){ ?><?php echo $embed_code; ?><?php } ?>
								<?php if($vidtype == '2' && !empty($vidvimeo)){ ?><?php echo $embed_code2; ?><?php } ?>
								<?php if($vidtype == '3' && !empty($vidfb)){ ?><?php echo $embed_code3; ?><?php } ?>	
							</div>
						</div>
						
						<div class="m-all t-all d-1of4 cf last-col">	
							
							<ul class="post-video-latest">
								<h3>Latest Videos</h3>
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 3, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
									$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
									$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
									$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
									  
									  
											<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span>
												<h3><?php the_title(); ?></h3>
												
												
												</span>
												
							<?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videotabimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videotabimage"></div>

				            <?php } ?>
				            
				            </a></li>
										
												
 
									  <?php
									  
									endforeach; 
									wp_reset_postdata();
									?>
								
								
								<a href="<?php echo get_home_url(); ?>/videos"><h4 class="red-btn">More Videos</h4>	</a>
							</ul>
									
									
						</div>
						</div>
			  	</div>
			  	
			  	
				
						
 
 
 
  </section>	
							
	<?php endwhile; ?>
<?php else : ?>
<?php endif; ?>

					<div id="inner-content" class="wrap wrap-2 cf">				

					<main id="main" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">


						<?php if (have_posts()) : while (have_posts()) : the_post();
							$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
							 ?>
							 
							
							<?php get_template_part( 'post-design/format-video', get_post_format() ); ?>
							
							
							
							<div class="post-bottom-bar">
								<ul class="post-share-mobile">
									<h4>Share</h4>
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
							</div>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'Oops, Post Not Found!', 'bonestheme' ); ?></h1>
									</header>
									<section class="entry-content">
										<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'bonestheme' ); ?></p>
									</section>
									<footer class="article-footer">
											<p><?php _e( 'This is the error message in the single.php template.', 'bonestheme' ); ?></p>
									</footer>
							</article>

						<?php endif; ?>

						
						
				
						
					</main>
					
					
					
				</div> <!-- end inner-content -->
				
				
				<?php include('template-morearticles.php');?>

			</div> <!-- end #content -->

<?php get_footer(); ?>


