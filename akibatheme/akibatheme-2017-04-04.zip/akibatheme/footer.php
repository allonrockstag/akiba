			
			<div class="md-modal md-effect-7" id="modal-7"> 
			<div class="md-content">
				<div>
					
				<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput" class="sb-search-input" placeholder="Search for an article.." type="text" value="" name="s" id="s" autofocus>
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>
				<button class="md-close"><img src="<?php echo get_template_directory_uri(); ?>/library/images/btn-close.png"</button>
					
				</div>
			</div>
			</div>
		<div class="md-overlay"></div><!-- the overlay element -->
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/modalEffects.js"></script>
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/cssParser.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/css-filters-polyfill.js"></script>
		
		
		<div class="footer-social">
			<div class="wrap cf">
				
					
					<ul class="footer-follow">
						<h4>Follow Us</h4>
						<li><a href="https://www.facebook.com/theakibapress/"><img src="<?php echo get_template_directory_uri(); ?>/library/images/icon-facebook.png"></a></li>
						<li><a href="https://www.instagram.com/akibapress/"><img src="<?php echo get_template_directory_uri(); ?>/library/images/icon-instagram.png"></a></li>
					</ul>
			</div>
		</div>
		<footer class="footer" id="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
				<div class="footer-middle">
					<div id="inner-footer" class="wrap cf">
					
					<div class="m-all t-1of5 d-1of5">
							<div class="footer-right">
								<img class="footer-logo" src="<?php echo get_template_directory_uri(); ?>/library/images/akibapress-logo.png">
							</div>
						</div>
						
					<div class="m-all t-1of5 d-1of5">
					<section class="ac-container-footer">
	                  <?php $countfaq = 1; ?>
	                  <div class="ac-container-box" id="footer-sections"> 
								<input id="ac-<?php echo $countfaq ?>b" name="accordion-<?php echo $countfaq ?>b" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>b">Sections</label>
								<article class="ac-small">
									<nav role="navigation">
						<?php wp_nav_menu(array(
    					'menu' => __( 'Footer Links', 'bonestheme' ),   // nav name
    					'menu_class' => 'footer-nav cf',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
						</nav>
								</article>
						</div>
	                  	
                  	</section>
                  	
					
					</div>
					<div class="m-all t-2of5 d-2of5 cf">
						<section class="ac-container-footer">
	                  <?php $countfaq = 1; ?>
	                 
						<div class="ac-container-box" id="footer-topics">
								<input id="ac-<?php echo $countfaq ?>c" name="accordion-<?php echo $countfaq ?>c" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>c">Topics</label>
								<article class="ac-small">
									<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav cf',
						'menu' 			=> 'FooterNav2' 
						
						)); ?>
						</nav>
								</article>
						</div>
						
                  	</section>
						
						
					</div>

						<div class="m-all t-1of5 d-1of5 cf last-col">
								<section class="ac-container-footer">
	                  <?php $countfaq = 1; ?>
	                  
						<div class="ac-container-box" id="footer-about">
								<input id="ac-<?php echo $countfaq ?>d" name="accordion-<?php echo $countfaq ?>d" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>d">About</label>
								<article class="ac-small">
									<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav cf',
						'menu' 			=> 'FooterNav3' 
						
						)); ?>
						</nav>
								</article>
						</div>
						
                  	</section>
							
						</div>

						
					
					

					</div>
					
				</div>
				
				<div class="footer-end">
				<div id="inner-footer" class="wrap cf">
				<div class="m-all t-all d-all cf">
					<p class="source-org copyright">&copy; <?php echo date('Y'); ?> Akiba Press. All Rights Reserved.<br/>
					<a href="<?php echo get_home_url(); ?>/privacy">Privacy Policy</a> | <a href="<?php echo get_home_url(); ?>/terms-of-service">Terms of Service</a></p>
				</div>
				</div>
				</div>

			</footer>

		</div>

		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>
		
		
		
		
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/classie.js"></script>
	

		<script src="<?php echo get_template_directory_uri(); ?>/library/js/fluidvids.js"></script>
		


		<script>
fluidvids.init({
  selector: ['iframe'],
  players: ['www.youtube.com', 'player.vimeo.com']
});

$(function(){
$('#section-iconbox-1 iframe[src*="youtube.com"]').attr('id','video1');
$('#section-iconbox-2 iframe[src*="youtube.com"]').attr('id','video2');
$('#section-iconbox-3 iframe[src*="youtube.com"]').attr('id','video3');
$('#section-iconbox-4 iframe[src*="youtube.com"]').attr('id','video4');
$('#section-iconbox-5 iframe[src*="youtube.com"]').attr('id','video5');
$('#section-iconbox-6 iframe[src*="youtube.com"]').attr('id','video6');
$('#section-iconbox-7 iframe[src*="youtube.com"]').attr('id','video7');
$('#section-iconbox-8 iframe[src*="youtube.com"]').attr('id','video8');
});



</script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/jquery-2.1.1.js"></script>
		<?php include('jscript-main.php');?>
		
		
	<script src="<?php echo get_template_directory_uri(); ?>/library/js/cbpFWTabs.js"></script>
		<script>
			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
		</script>
		
		
		<script>
					
			// global variable for the player
			var player1;
			var player2;
			var player3;
			var player4;
			var player5;
			var player6;
			var player7;
			var player8;
			
			// this function gets called when API is ready to use
			function onYouTubePlayerAPIReady() {
			  // create the global player from the specific iframe (#video)
			  player1 = new YT.Player('video1', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player2 = new YT.Player('video2', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player3 = new YT.Player('video3', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player4 = new YT.Player('video4', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player5 = new YT.Player('video5', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player6 = new YT.Player('video6', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  
			}
			  var pauseButton1 = document.getElementById("pause-button-1");
			  var pauseButton2 = document.getElementById("pause-button-2");
			  var pauseButton3 = document.getElementById("pause-button-3");
			  var pauseButton4 = document.getElementById("pause-button-4");
			  var pauseButton5 = document.getElementById("pause-button-5");
			  var pauseButton6 = document.getElementById("pause-button-6");
			  
			  
			function onPlayerReady(event) {
			  //var pauseButton = document.getElementsByClassName('tab-not-current');
			  pauseButton1.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton2.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton3.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton4.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton5.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton6.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  
			}
			
			// Inject YouTube API script
			var tag = document.createElement('script');
			tag.src = "//www.youtube.com/player_api";
			var firstScriptTag = document.getElementsByTagName('script')[0];
			firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
			
			
			
		
		</script>

		


	</body>

</html> <!-- end of site. what a ride! -->
